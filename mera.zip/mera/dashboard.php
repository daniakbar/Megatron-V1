                <?php include'header.php' ?>
                <!-- Sidebar -->
                <?php include'sidebar.php' ?>

                <!-- Menu Content -->
                <div class="uk-width-medium-1-1 uk-width-large-8-10 uk-width-small-1-1 uk-width-small-1-1 shadow main uk-panel"  >

                   <div class="uk-block uk-block-border uk-block-default uk-margin-top uk-margin-bottom">

                        <div class="uk-container">
                            <h2 class="uk-margin-bottom-remove">Selamat Datang!</h2>
                            <h5 class="uk-margin-top-remove uk-margin-bottom">Akses cepat untuk menu penting :</h5>

                                <div class="uk-grid uk-grid-match uk-margin-top" data-uk-grid-margin>
                                    <div class="uk-width-medium-1-3">
                                        <div class="uk-panel">
                                            <h3>Get Started</h3>
                                            <p><a href="#" class="uk-button uk-button-primary"><i class="uk-icon-edit"></i> Costumize</a></p>
                                            <small>or, change your theme completely</small>
                                        </div>
                                    </div>

                                    <div class="uk-width-medium-1-3">
                                        <div class="uk-panel">
                                            <h3>Next Action</h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                        </div>
                                    </div>
                                    <div class="uk-width-medium-1-3">
                                        <div class="uk-panel">
                                        <h3>Help!</h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                        </div>
                                    </div>
                                </div>

                        </div>


                   </div>

                   <div class="uk-block uk-block-border uk-block-default uk-margin-bottom">

                        <div class="uk-container">

                            <h3 class="uk-margin-top"><i class="uk-icon-gear uk-margin"></i> News Update</h3>

                            <div class="uk-article-divider"></div>

                                <div class="uk-grid uk-grid-divider">
                                    <div class="uk-width-medium-1-2">
                                        <div class="uk-panel">
                                            <h3>Update 1.1 <span class="uk-badge uk-badge-success">Baru</span></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                        </div>

                                        <div class="uk-grid-divider"></div>

                                    </div>

                                    <div class="uk-width-medium-1-2">
                                        <div class="uk-panel">
                                            <h3 class="">Quick Draft</h3>
                                            <form class="uk-form">

                                                <fieldset data-uk-margin>

                                                    <div class="uk-form-row">
                                                        <input class="uk-width-1-1" type="text" placeholder="Judul" name="title"></input>
                                                    </div>

                                                    <div class="uk-form-row">
                                                        <textarea class="uk-width-1-1" cols="2" rows="5" placeholder="Konten disini..." name="content"></textarea>
                                                    </div>

                                                    <div class="uk-form-row">
                                                        <input type="submit" value="Save Draft" class=" uk-text-contrast uk-button uk-button-primary uk-button-large uk-icon-check">
                                                        </input>
                                                    </div>

                                                </fieldset>

                                            </form>
                                        </div>
                                    </div>

                                </div>

                        </div>

                   </div>

                </div>
                <!-- Menu Content  -->

            </div>
            <!-- Main -->

        </div>
        <!-- Container -->
        <?php include'footer.php'?>
