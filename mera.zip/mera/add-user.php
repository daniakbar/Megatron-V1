                <?php include'header.php' ?>
                <!-- Sidebar -->
                <?php include'sidebar.php' ?>
                <!-- Menu Content -->
                <div class="uk-width-medium-1-1 uk-width-large-8-10 uk-width-small-1-1 shadow ">

                   <div class="uk-block uk-block-border uk-block-default uk-margin-top uk-margin-bottom">

                        <div class="uk-container">
                            <h2 class="uk-margin-bottom-remove">My Profile</h2>
                            <h5 class="uk-margin-top-remove uk-margin-bottom">Your basic profile Your basic profile Your basic profile</h5>
                        </div>


                   </div>

                   <div class="uk-block uk-block-border uk-block-default">

                        <div class="uk-container">

                                <h3 class="uk-margin-top"><i class="uk-icon-gear uk-margin"></i> Basic Info</h3>

                                <div class="uk-article-divider"></div>

                                
                            <form class="uk-form uk-form-horizontal">
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">User Name</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">First Name</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Last Name</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Nicknamce (required)</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                               
                               <div class="uk-article-divider"></div>
                               
                                <h3 class="uk-margin-top"><i class="uk-icon-gear uk-margin"></i> Contact Info</h3>

                                <div class="uk-article-divider"></div>

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Email (required)</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Website</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Facebook</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Twitter</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Linkedin</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Dribbble</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Google+</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->

                                <div class="uk-article-divider"></div>

                                <h3 class="uk-margin-top"><i class="uk-icon-gear uk-margin"></i> About Yourself</h3>

                                <div class="uk-article-divider"></div>

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-s">Photo</label>
                                    <div class="uk-form-controls">
                                        <div id="profile-imagePreview" style="background-image: url('http://localhost/mera/img/avatar.svg');"></div>
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    
                                    <label class="uk-form-label" for="form-h-s">Change Photo Profile</label>
                                    <div class="uk-form-controls">
                                        <input class="uk-form-file" id="upload-select" type="file"></input>
                                        <p class="uk-article-meta">picture size 180 x 180px</p>
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-s">Biographical Info</label>
                                    <div class="uk-form-controls">
                                        <textarea class="uk-width-1-2"></textarea>
                                    </div>
                                </div>
                                <!--  -->

                                <div class="uk-article-divider"></div>

                                <h3 class="uk-margin-top"><i class="uk-icon-gear uk-margin"></i> Account Management</h3>

                                <div class="uk-article-divider"></div>

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-s">Password</label>
                                    <div class="uk-form-controls">
                                        <input class="uk-form-file" type="password"></input>
                                    </div>
                                </div>
                                <!--  -->

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-s">Session</label>
                                    <div class="uk-form-controls">
                                        <button class="uk-form-file" type="submit">Logout Everywhere else</button> 
                                        <p class="uk-article-meta">Did you lose your phone or leave your account logged in at a public computer? You can log out everywhere else, and stay logged in here. </p>
                                    </div>
                                </div>
                                <!--  -->


                                <div class="uk-article-divider"></div>


                                <!--  -->
                                <div class="uk-form-row">
                                    <div class="uk-form-controls">
                                        <button type="submit" class=" uk-button uk-button-primary">Add New</button>
                                </div>
                                <!--  -->
                                
                            </form>

                        </div>

                   </div>

                </div>
                <!-- Menu Content  -->

            </div>
            <!-- Main -->

        </div>
        <!-- Container -->
        <?php include'footer.php'?>
