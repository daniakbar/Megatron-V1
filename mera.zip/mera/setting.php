                <?php include'header.php' ?>
                <!-- Sidebar -->
                <?php include'sidebar.php' ?>
                <!-- Menu Content -->
                <div class="uk-width-medium-1-1 uk-width-large-8-10 uk-width-small-1-1 shadow ">

                   <div class="uk-block uk-block-border uk-block-default uk-margin-top uk-margin-bottom">

                        <div class="uk-container">
                            <h2 class="uk-margin-bottom-remove">My Setting</h2>
                            <h5 class="uk-margin-top-remove uk-margin-bottom">Your basic setting Your basic setting Your basic setting</h5>
                        </div>


                   </div>

                   <div class="uk-block uk-block-border uk-block-default">

                        <div class="uk-container">

                                <h3 class="uk-margin-top"><i class="uk-icon-gear uk-margin"></i> Basic Setting</h3>

                                <div class="uk-article-divider"></div>

                                
                            <form class="uk-form uk-form-horizontal">
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Nama Website</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Url Website</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Deskripsi SEO</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-it">Kata Kunci SEO</label>
                                    <div class="uk-form-controls">
                                        <input type="text" id="form-h-it" placeholder="Text input">
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-s">Tema admin</label>
                                    <div class="uk-form-controls">
                                        <select id="form-h-s">
                                            <option>Light Blue</option>
                                            <option>Dark</option>
                                        </select>
                                    </div>
                                </div>
                                <!--  -->
                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-s">Zona Waktu</label>
                                    <div class="uk-form-controls">
                                        <select id="form-h-s">
                                            <option>UTC-11.00 Pacivic/Midway</option>
                                            <option>UTC-10.00 Bali/Bali</option>
                                        </select>
                                    </div>
                                </div>
                                <!--  -->
                                <div class="uk-grid-divider"></div>

                                <!--  -->
                                <div class="uk-form-row">
                                    <label class="uk-form-label" for="form-h-s">Favicon</label>
                                    <div class="uk-form-controls">
                                        <input class="uk-form-file" type="file"></input>
                                    </div>
                                </div>
                                <!--  -->
                                
                            </form>

                        </div>

                   </div>

                </div>
                <!-- Menu Content  -->

            </div>
            <!-- Main -->

        </div>
        <!-- Container -->
        <?php include'footer.php'?>
